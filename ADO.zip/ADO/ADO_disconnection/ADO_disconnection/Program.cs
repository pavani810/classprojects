﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_disconnection
{
    class Program
    {
        static string constring = Properties.Settings.Default.constring;
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(" ---- BEFORE MODIFICATION ----- ");

                DisplayData();

                InsertData();
                //UpdateData();
                //DeleteData();

                Console.WriteLine(" ---- AFTER MODIFICATION ----- ");
                DisplayData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeleteData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    string selectString = @"SELECT * FROM EMPLOYEES";
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Fill(ds);
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        if ((int)dr["EmployeeID"] == 14)
                            dr.Delete();
                    }
                    da.Update(ds);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while deleting data: {ex.Message}");
            }
        }
        private static void UpdateData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    string selectString = @"SELECT * FROM EMPLOYEES";
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Fill(ds);
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        if ((int)dr["EmployeeID"] == 7)
                            dr["FirstName"] = "Bob";
                    }
                    da.Update(ds);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while inserting data: {ex.Message}");
            }
        }
        private static void InsertData()
           {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    string selectString = @"Select * from employees";
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(selectString, con);

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Fill(ds);
                    DataRow dr = ds.Tables[0].NewRow();
                    dr["FirstName"] = "Donald";
                    dr["LastName"] = "trump";
                    DataTable dt = ds.Tables[0];
                    dt.Rows.Add(dr);
                    da.Update(ds);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while updating data: {ex.Message}");
            }
        }
        private static void DisplayData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    string cmdString = @"SELECT * FROM EMPLOYEES";
                    using (SqlCommand cmd = new SqlCommand(cmdString, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            Console.WriteLine(dr["FirstName"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while displaying data: {ex.Message}");
            }
        }
    }
}