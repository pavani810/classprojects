﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication34
{
    class Program
    {
       static string conString = @"Server=INCHCMPC08679;Database=NorthWind;Trusted_Connection=True;";

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("---- Before Modification  -----");
                DisplayData();
                InsertData();

                Console.WriteLine("---- After Modification  -----");
                DisplayData();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter( "INSERT INTO EMPLOYEES(FirstName, LastName) values('John', 'Rambo')",con);
               // string innerString = @"INSERT INTO EMPLOYEES(FirstName,LastName) values ('John','Rambo')";
                using (SqlCommandBuilder cmd = new SqlCommandBuilder (adapter))
                {
                    cmd.ExecuteNonQuery();
                }
            }

        }

        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"Select * from Employees";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"EmployeeID : {rdr[0]} | FirstName : {rdr[1]}");
                    }
                }
            }
        }
    }
}  

​


