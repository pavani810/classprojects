﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO1
{
    class Program
    {
        static string conString = @"Server=INCHCMPC11330;Database=Northwind;trusted_connection=true;";

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(" ---- BEFORE MODIFICATION ----- ");
                DisplayCount();
                DisplayData();

                //InsertData();
                //UpdateData();
                //DeleteData();

                Console.WriteLine(" ---- AFTER MODIFICATION ----- ");
                DisplayData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void DeleteData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"DELETE FROM Employees WHERE EmployeeID = 12";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void UpdateData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"UPDATE Employees SET FirstName = 'Jack' WHERE EmployeeID = 12";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string insertString = @"INSERT INTO Employees (FirstName, LastName) VALUES ('John', 'Rambo') ";
                using (SqlCommand cmd = new SqlCommand(insertString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT * FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"FirstName: {rdr["FirstName"]}  | LastName: {rdr["LastName"]}");
                    }
                }

            }
        }

        private static void DisplayCount()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT COUNT(*) FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    int count = (int)cmd.ExecuteScalar();
                    Console.WriteLine($"Total no. of records = {count}");
                }
            }
        }

    }
}
