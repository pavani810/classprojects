﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO1
{
    class Program
    {
        private static string selectAllString;

        static void Main(string[] args)
        {
            try
            {
                string conString = @"Server = INCHCMPC09350; Database = Northwind;Trusted_Connection = True;";

                using (SqlConnection con = new SqlConnection(conString))
                { 
                    con.Open();
                using(SqlCommand cmd = new SqlCommand(selectAllString, con));
                    { }
                //    con.ConnectionString = con;
                cmd.Connection = con;
                cmd.CommandText = @"SELECT * FROM EMPLOYEES";
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Console.WriteLine($"EmployeeID:{rdr[0]} | FirstName:{rdr[1]} ");
                }
                con.Close();
                cmd.Dispose();
                con.Dispose();
            }
            catch( Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
