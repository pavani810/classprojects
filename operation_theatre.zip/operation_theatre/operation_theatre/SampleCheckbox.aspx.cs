﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace operation_theatre
{
    public partial class SampleCheckbox : System.Web.UI.Page
    {
        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlConnection con = new SqlConnection(_connStr);
                SqlCommand cmd = new SqlCommand("select * from Staff_Details11", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();
                sda.Fill(dt);
                CheckBoxList1.DataSource = dt;
                CheckBoxList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string k = "";
            for (int i = 0; i < CheckBoxList1.Items.Count; i++)
            {
                if (CheckBoxList1.Items[i].Selected)
                {

                    k = k + CheckBoxList1.Items[i].Text + "</br>";
                }

            }
            lb_msg.Text = k;
            lb_msg.ForeColor = System.Drawing.Color.ForestGreen;
        }
    }

}


  
