﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Windows.Forms;

namespace operation_theatre
{
    public partial class Details_of_Staff_interface : System.Web.UI.Page
    {

        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void btn_StaffSubmit_Click(object sender, EventArgs e)
        {

            string Anasthesiast_Name = string.Empty;
            if (Rbn_Christo.Checked)
            {
                Anasthesiast_Name = "Christo";
            }
            else if (Rbn_Charles.Checked)
            {
                Anasthesiast_Name = "Charles";
            }
            else if (Rbn_Oliver.Checked)
            {
                Anasthesiast_Name = "Oliver";
            }



            string Doctor_Name = string.Empty;
            if (Rbn_Nancy.Checked)
            {
                Doctor_Name = "Nancy Davolio";
            }
            else if (Rbn_Andrew.Checked)
            {
                Doctor_Name = "Andrew Fuller";
            }
           else if (Rbn_Janet.Checked)
            {
                Doctor_Name = "Janet Leverling ";
            }
           else if (Rbn_Christo.Checked)
            {
                Doctor_Name = "Michael Suyana";
            }
           else if (Rbn_Flancy.Checked)
            {
                Doctor_Name = "Flancy Fiona";
            }
           else if (Rbn_Laura.Checked)
            {
                Doctor_Name = "Laura Callahin";
            }
           else if (Rbn_Laurel.Checked)
            {
                Doctor_Name = "Laurel Lance";
            }
            else if (Rbn_Oqueen.Checked)
            {
                Doctor_Name = "Oliver Queen";
            }

            string Supporting_Staff = Che_Carl.Checked ? "Carl" : "Null";
            string Supporting_Staff1 = Che_Bris.Checked ? "Bris" : "NULL";
            string Supporting_Staff2 = Che_Harris.Checked ? "Harris" : "NULL";
            string Supporting_Staff3 = Che_Chris.Checked ? "Chris" : "NULL";
            string Supporting_Staff4 = Che_Lance.Checked ? "Lance" : "NULL";
            string Supporting_Staff5 = Che_Mary.Checked ? "Mary" : "NULL";



            //System.Web.UI.WebControls.CheckBox[] boxes = new System.Web.UI.WebControls.CheckBox[11];
            //boxes[0] = Che_Carl;
            //boxes[1] = Che_Bris;
            //boxes[2] = Che_Harris;
            //boxes[3] = Che_Chris;
            //boxes[4] = Che_Lance;
            //boxes[5] = Che_Mary;
            //boxes[6] = Che_Sonia;
            //boxes[7] = Che_Clara;
            //boxes[8] = Che_Aarshi;
            //boxes[9] = Che_Tanmay;
            //boxes[10] = Che_Clovia;

            ////string[] Staff = new string[11];
            ////for(int i=0;i<Staff.Length;i++)
            ////{
            ////    Staff[i]==
            ////}
            //string[] Supporting_Staff = new string[11];
            //for (int i = 0; i <= 11; i++)
            //{

            //    if (boxes[i].Checked == true && boxes[i].Enabled)
            //    {
            //        int count = 0;
            //        //string[] Supporting_Staff = new string[11];
            //        for (count = 0; count < Supporting_Staff.Length; count++)
            //        {
            //            MessageBox.Show(boxes[i] + " is clicked");
            //            Supporting_Staff[count] = boxes[i].Checked ? boxes[i].Text : "Null";
            //        }
            //    }

            //}




            string Equipment1 = Che_Hydraulic.Checked ? "Hydraulic" : "NULL";
            string Equipment2 = Che_OTTable.Checked ? "OT Light Halogen" : "NULL";
            string Equipment3 = Che_Stand.Checked ? "Stand" : "NULL";
            string Equipment4 = Che_Suction.Checked ? "Suction Machine" : "NULL";
            string Equipment5 = Che_Autoclave.Checked ? "Autoclave" : "NULL";
            string Equipment6 = Che_Sterilizer.Checked ? "Sterilizer Machine" : "NULL";
            string Equipment = Che_Equipmentkit.Checked ? "Surgical Equipment Kit" : "NULL";







            try
            {

                using (SqlConnection con = new SqlConnection(_connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Operation_Schedule1(Anasthesiast_Name,Doctor_Name,Supporting_Staff,Supporting_Staff1,Supporting_Staff2,Supporting_Staff3,Supporting_Staff4,Supporting_Staff5,Equipment,Equipment1,Equipment2,Equipment3,Equipment4,Equipment5,Equipment6) VALUES(@anasthesiast_Name,@doctor_Name,@supporting_Staff,@supporting_Staff1,@supporting_Staff2,@supporting_Staff3,@supporting_Staff4,@supporting_Staff5,@equipment,@equipment1,@equipment2,@equipment3,@equipment4,@equipment5,@equipment6)"))
                    //using (SqlCommand cmd = new SqlCommand("INSERT INTO Operation_Schedule3(Anasthesiast_Name,,Doctor_Name,Supporting_Staff,Supporting_Staff1,Supporting_Staff2,Supporting_Staff3,Supporting_Staff4,Supporting_Staff5)values(@anasthesiast_Name,@doctor_Name,@supporting_Staff,@supporting_Staff1,@supporting_Staff2,@supporting_Staff3,@supporting_Staff4,@supporting_Staff5,@supporting_Staff6)"))
                    {
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@anasthesiast_Name", Anasthesiast_Name);
                        cmd.Parameters.AddWithValue("@doctor_Name", Doctor_Name);
                        cmd.Parameters.AddWithValue("@supporting_staff", Supporting_Staff);
                        cmd.Parameters.AddWithValue("@supporting_staff1", Supporting_Staff1);
                        cmd.Parameters.AddWithValue("@supporting_staff2", Supporting_Staff2);
                        cmd.Parameters.AddWithValue("@supporting_staff3", Supporting_Staff3);
                        cmd.Parameters.AddWithValue("@supporting_staff4", Supporting_Staff4);
                        cmd.Parameters.AddWithValue("@supporting_staff5", Supporting_Staff5);

                        //for( int i=0;i<11;i++)
                        //{
                        //    cmd.Parameters.AddWithValue("@supporting_Staff", Supporting_Staff[i]);
                        //}



                        cmd.Parameters.AddWithValue("@Equipment", Equipment);
                        cmd.Parameters.AddWithValue("@Equipment1", Equipment1);
                        cmd.Parameters.AddWithValue("@Equipment2", Equipment2);
                        cmd.Parameters.AddWithValue("@Equipment3", Equipment3);
                        cmd.Parameters.AddWithValue("@Equipment4", Equipment4);
                        cmd.Parameters.AddWithValue("@Equipment5", Equipment5);
                        cmd.Parameters.AddWithValue("@Equipment6", Equipment6);
                       
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            MessageBox.Show("Submission is Successfull");
        }
    }
}
