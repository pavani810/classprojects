﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




namespace operation_theatre
{
    public partial class Patient_Details : System.Web.UI.Page
    {

        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";


        protected void Page_Load(object sender, EventArgs e)


        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Patient_Details", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds2 = new DataSet();

            da.Fill(Ds2, "Patient_Details");
            GridView1.DataSource = Ds2.Tables[0];

            GridView1.DataBind();
            con.Close();

        }
        protected void ImgPatientHome_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Admin interface.aspx");

        }
        protected void ImgPatientLogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("loginDetails.aspx");

        }


    }
}
