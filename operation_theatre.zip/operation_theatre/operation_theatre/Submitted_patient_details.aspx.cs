﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace operation_theatre
{
    public partial class Submitted_patient_details : System.Web.UI.Page
    {
        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Operation_Schedule1", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds15 = new DataSet();

            da.Fill(Ds15, "Operation_Schedule1");
            GridView1.DataSource = Ds15.Tables[0];

            GridView1.DataBind();
            con.Close();

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Staff_loginsample.aspx");
        }
    }
}