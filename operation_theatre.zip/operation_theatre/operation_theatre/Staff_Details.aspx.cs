﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




namespace operation_theatre
{
    public partial class Staff_Details : System.Web.UI.Page
    {

        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";


        protected void Page_Load(object sender, EventArgs e)


        {

        }


        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Staff_Details", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds3 = new DataSet();

            da.Fill(Ds3, "Staff_Details");
            GridView1.DataSource = Ds3.Tables[0];

            GridView1.DataBind();
            con.Close();

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImgStaffDetailsHome_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Admin interface.aspx");

        }

        protected void ImgStaffdetailslogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("loginDetails.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
