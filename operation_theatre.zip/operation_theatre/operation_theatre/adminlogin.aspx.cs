﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace operation_theatre
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public partial class RTA_OfficerLoginPage : System.Web.UI.Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {
                if (!IsPostBack)
                    Session["admin"] = string.Empty;
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == "admin" && txt_adminpassword.Text == "admin123")
            {
                Session["admin"] = txt_loginid.Text;
                Response.Redirect("AdminPage.aspx");
            }
            else
            {
                MessageBox.Show("Please provide the valid login credentials", "Invalid login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}





