﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace operation_theatre
{
    public partial class Operation_Details : System.Web.UI.Page
    {
        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Operation_Details ", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds8 = new DataSet();

            da.Fill(Ds8, "Operation_Details");
            GridView1.DataSource = Ds8.Tables[0];

            GridView1.DataBind();
            con.Close();
        }

        protected void Img_OperadetailsHome_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Admin interface.aspx");

        }

        protected void Img_Operadetailslogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("loginDetails.aspx");

        }
    }
}