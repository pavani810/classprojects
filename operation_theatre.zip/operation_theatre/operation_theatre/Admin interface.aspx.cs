﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace operation_theatre
{
    public partial class Admin_interface : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
           
            if (DropDownList1.SelectedItem.Text == "Doctordetails")
            {
                Response.Redirect("doctor_opera.aspx");
            }
            else if (DropDownList1.SelectedItem.Text == "PatientDetails")
            {
                Response.Redirect("Patient_Details.aspx");
            }
            else if (DropDownList1.SelectedItem.Text == "StaffDetails")
            {
                Response.Redirect("Staff_Details.aspx");
            }
            else if (DropDownList1.SelectedItem.Text == "Operation_Details")
            {
                Response.Redirect("Operation_Details.aspx");
            }
            else if (DropDownList1.SelectedItem.Text == "OperationTheatreEquipment")
            {
                Response.Redirect(" OperationTheatreEquipment.aspx");
            }
            
            else
            {
                Response.Redirect(" EquipmentsList.aspx");
            }

        }
    }
    }
