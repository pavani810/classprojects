﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace operation_theatre
{
    public partial class searching_details : System.Web.UI.Page
    {
        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGrid();
            }
        }

        private void BindGrid()      //this method is to display the details of the patient give in the search box
        { 
            try
            {

                using (SqlConnection con = new SqlConnection(_connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = " SELECT * FROM Operation_Details WHERE  Patient_FirstName  = '" + TextBox1.Text.Trim() + "'";
                        cmd.Connection = con;

                        DataTable ds = new DataTable();
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(ds);
                            if (ds.Rows.Count>0)
                            {
                                GridView1.DataSource = ds;
                                GridView1.DataBind();
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


            protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            //if (GridView1.EditIndex != -1)
            //{
            //    // Use the Cancel property to cancel the paging operation.
            //    e.Cancel = true;

            //    // Display an error message.
            //     int newPageNumber = e.NewPageIndex +1;
            //     message.Text = "Please update the record before moving to page " + newPageNumber.ToString() + ".";

            GridView1.PageIndex = e.NewPageIndex;

            this.BindGrid();
        }
        //else
        //{
        //    // Clear the error message.
        //    message.Text = "";
        //}


        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Text = Regex.Replace(e.Row.Cells[0].Text, TextBox1.Text.Trim(), delegate (Match match)
                {
                    return string.Format("<span style = 'background-color:#D9EDF7'>{0}</span>", match.Value);
                }, RegexOptions.IgnoreCase);
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button7_Click(object sender, EventArgs e)
        {

            this.BindGrid();
            //public DataSet Bind()
            //{
            //    SqlConnection con = new SqlConnection(_connStr);
            //    SqlCommand cmd = new SqlCommand("select * from Employe where Empname like'" + TextBox1.Text + "%'", con);
            //    SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds);
            //    if (!object.Equals(ds, null))
            //    {
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            GridView1.DataSource = ds.Tables[0];
            //            GridView1.DataBind();
            //        }

            //    }


            //    return ds;
        }

        protected void Button1_Click(object sender, EventArgs e)

        {

            //  DataSet ds = Bind();

            //            if (!object.Equals(ds, null))
            //            {
            //                if (ds.Tables[0].Rows.Count > 0)
            //                {
            //                    GridView1.Visible = true;
            //                    TextBox1.Text = " ";
            //                    message.Text = " ";
            //                }


            //                else
            //                {
            //                    GridView1.Visible = false;
            //                    message.Visible = true;
            //                    message.Text = "not available in the record";

            //                }

            //            }

            //        }
            //    }
            //}
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}





    