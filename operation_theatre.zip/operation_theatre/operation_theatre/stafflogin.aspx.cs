﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace operation_theatre
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load1(object sender, EventArgs e)
        {

        }

     public int validate_login1(string userid, string password, string login)
        {

            string cs = "server=.\\LPUDB;database=Project;user id=sa;pwd=11210646";
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = login;
            cmd.Parameters.AddWithValue("@userid", userid);
            cmd.Parameters.AddWithValue("@password", password);

            cmd.Parameters.Add("@result", System.Data.SqlDbType.Int, 4);
            cmd.Parameters["@result"].Direction = System.Data.ParameterDirection.Output;
            cmd.Connection = conn;
            int result = 0;
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                result = (int)cmd.Parameters["@result"].Value;
            }
            catch (SqlException ex) { lblmessage.Text = ex.Message; }
            finally
            {

                if (conn != null)
                {
                    conn.Close();
                }
            }

            return result;
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            int results = 0;
            if (TextBox1.Text.Trim().Length == 2 || TextBox1.Text.Trim().Length == 9)
            {
                string login = "stafflogin";
                results = validate_login1(TextBox1.Text.Trim(), TextBox2.Text.Trim(),login);
                if (results == 1)
                {
                    Session["staffid"] = TextBox1.Text.Trim();
                    Response.Redirect("staffProfile.aspx");
                }
                else
                {
                    lblmessage1.Text = "Invalid Login";
                }
            }
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
