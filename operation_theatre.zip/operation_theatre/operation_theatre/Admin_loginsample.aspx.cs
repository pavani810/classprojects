﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace operation_theatre
{
    public partial class Admin_loginsample : System.Web.UI.Page
    {
        string cs = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_adminlogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from admincredentials where adminid=@userid and adminpassword=@password", con);
            cmd.Parameters.AddWithValue("@userid", adminID.Text);
            cmd.Parameters.AddWithValue("@password", Adminpass.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["admin"] = adminID.Text;
                Response.Redirect("Admin interface.aspx");
            }
           else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            }
            con.Close();
        }

    }
}