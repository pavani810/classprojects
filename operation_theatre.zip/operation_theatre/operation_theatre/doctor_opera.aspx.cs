﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




namespace operation_theatre
{
    public partial class doctor_opera : System.Web.UI.Page
    {

        string _connStr = ConfigurationManager.ConnectionStrings["doctorConnectionString"].ConnectionString;


        protected void Page_Load(object sender, EventArgs e)


        {

        }
        protected void btn_doctor_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Doctor_Details", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds1 = new DataSet();

            da.Fill(Ds1, "Doctor_Details");

            GridView1.DataSource = Ds1.Tables[0];

            GridView1.DataBind();
            con.Close();

        }

        protected void Img_Doclogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("loginDetails.aspx");
        }

       
        protected void Img_DocHome_Click1(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Admin interface.aspx");
        }
    }
}
