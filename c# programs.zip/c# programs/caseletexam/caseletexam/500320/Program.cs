﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caseletexam
{
    class Program
    {
        public static List<DomesticAirport> dalist = new List<DomesticAirport>();
        public static List<InternationalAirport> calist = new List<InternationalAirport>();
        static void Main(string[] args)
        {
            string Confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Welcome to the  Airport Services");
                Console.WriteLine("1. DomesticAirport \n2. InternationalAirport");
                Console.ResetColor();
                int choice = GetInt("Enter the choice");


                switch (choice)
                {
                    case 1:
                        displayMenu();
                        DomesticAirport da = new DomesticAirport();
                        airportOptions(da);
                        break;

                   case 2:
                        displayMenu();
                        InternationalAirport ia = new InternationalAirport();
                       airportOptions(ia);
                        break;

                    default:
                        Console.WriteLine("Please choose a valid option");
                        break;
                }
                Console.WriteLine("Enter 'y' to continue");
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "Y");
        }
        public static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }
        public static void displayMenu()
        {
           
            Console.WriteLine("1.Add new airport");
            Console.WriteLine("2.Remove Airport");
            Console.WriteLine("3.Edit Airport");
            Console.WriteLine("4.Get details for new airport");
            Console.WriteLine("5.Show Airport details");
        }
        public static void airportOptions(DomesticAirport obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.AddNewAirport();
                    dalist.Add(obj);
                    break;
                case 2:
                    obj.RemoveAirport();
                    break;
                case 3:
                    obj.EditAirportDetails();
                    break;
                case 5:
                    obj.ShowAirportDetails();
                    break;
                case 4:
                    obj.GetDetailsForNewAirport();
                    break;
              
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }
        public static void airportOptions(InternationalAirport obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.AddNewAirport();
                    calist.Add(obj);
                    break;
                case 2:
                    obj.RemoveAirport();
                    break;
                case 3:
                    obj.EditAirportDetails();
                    break;
                case 4:
                    obj.ShowAirportDetails();
                    break;
                case 5:
                    obj.GetDetailsForNewAirport();
                    break;

                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }


    }
    }
