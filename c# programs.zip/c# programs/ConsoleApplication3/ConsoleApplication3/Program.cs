﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace ConsoleApplication3
{
    class Program
    {
       static Excel.Application xlApp = new Excel.Application();
        static Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"E:\attendance_sheet.xlsx");
        static Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
        static Excel.Range xlRange = xlWorksheet.UsedRange;

        static int rowCount = xlRange.Rows.Count;
        static int colCount = xlRange.Columns.Count;
        public static Random random = new Random();
        public static List<int> randomList = new List<int>();
        static void Main(string[] args)
        {
            List<int> randomNumbers = new List<int>();
            int MyNumber = 0;
            List<string> domains = new List<string>();
            for (int rw = 1; rw <= rowCount; rw++)
            {
                for (int cw = 1; cw <= colCount; cw++)
                {
                    if (xlWorksheet.Cells[rw, cw].Value != null)
                        domains.Add(xlWorksheet.Cells[rw, cw].Value.ToString());
                }
            }

            for (int i = 0; i <rowCount; i++)
            {
                int number;
                do number = random.Next(1, rowCount);
                while (randomNumbers.Contains(number));
                randomNumbers.Add(number);
                Console.WriteLine($"The GID is {domains[i]} and the seat is {randomNumbers[i]}");
            }
            Console.ReadLine();
        }
    }
}
