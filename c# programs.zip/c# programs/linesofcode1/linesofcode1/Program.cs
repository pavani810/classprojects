﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace linesofcode1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 c = new Class1();
            int count = 0;
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\MSLCELTP1045\Documents\Visual Studio 2015\Projects\seatingmodify\seatingmodify\Program.cs");
            count =  c.CountNumberOfLine(file);
           Console.WriteLine("hello3");
            Console.WriteLine(count);

        }
     

        }
    }

