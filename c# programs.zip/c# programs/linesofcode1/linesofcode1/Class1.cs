﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linesofcode1
{
    class Class1
    {
        public int CountNumberOfLine(System.IO.StreamReader tc)
        {
            int count = 0;
            int inComment = 0;
            string line = " ";
            Console.WriteLine("hello");
            while ((line = tc.ReadLine()) != null)
            {
                if (line.Trim() != tc.ReadLine() != null)
                {
                    if (IsRealCode(line.Trim(), ref inComment))
                    {
                        count++;
                        // Console.WriteLine(count);
                    }
                }
            }
            Console.WriteLine("hello2");
            return count;
        }

        public bool IsRealCode(string trimmed, ref int inComment)
        {
            if (trimmed.StartsWith("/*") && trimmed.EndsWith("*/"))
            {
                return false;
            }
            else if (trimmed.StartsWith("/*"))
            {
                inComment++;
                return false;
            }
            else if (trimmed.EndsWith("*/"))
            {
                inComment--;
                return false;
            }
            return
                inComment == 0
                && !trimmed.StartsWith("//")
                && !trimmed.StartsWith("/n")
                && (trimmed.StartsWith("if")
                || trimmed.StartsWith("else if")
                || trimmed.StartsWith("using (")
                 || trimmed.StartsWith("else if")
                || trimmed.Contains(";")
                || trimmed.StartsWith("public")
                || trimmed.StartsWith("private")
                || trimmed.StartsWith("protected")
               );


        }
    }
}
