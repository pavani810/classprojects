﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {

       static IEnumerable<Employee> le = new List<Employee>();
       static IEnumerable<Manager> lm = new List<Manager>();


        static void Main(string[] args)
        {
            Employee e1 = new Employee();
            Manager m1 = new Manager();
            iteration(le);
            iteration(lm);


        }
        static void iteration(IEnumerable<
            
            > li)
        {
            foreach (var item in li)
            {
                Console.WriteLine();
            }
            Console.WriteLine("inside the iteration method");
           
            Console.ReadLine();
        }
    }

    class Employee
    {
      public   int id = 1;
    }
    class Manager
    {
      public   int id = 2;
    }
}
