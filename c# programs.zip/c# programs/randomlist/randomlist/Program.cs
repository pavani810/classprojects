﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace randomlist
{
    class Program
    {
        static Random random = new Random();
        static void Main(string[] args)
        {
            List<int> randomNumbers = new List<int>();

            for (int i = 0; i < 42; i++)
            {
                int number;
                
                do number = random.Next(1,46);
                while (randomNumbers.Contains(number));

                randomNumbers.Add(number);
                Console.WriteLine(randomNumbers[i]);
            }
            Console.ReadLine();
        }
    }
}
