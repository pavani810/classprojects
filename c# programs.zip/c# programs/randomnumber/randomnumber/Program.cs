﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace randomnumber
{
    class Program
    {
        static Random random = new Random();
        static void Main(string[] args)
        {
            int a;
            HashSet<Int32> randomlist = new HashSet<Int32>();
            while (randomlist.Count <44)
            {
                a = random.Next(100);
                if(a<44 && a>0)
                randomlist.Add(a);
            }
            //for (int i = 0; i < randomlist.Count; i++)
            //{
            //    Console.WriteLine(randomlist[i]);
            //}
            foreach (int random1 in randomlist)

            {

                Console.WriteLine(random1);

            }
            Console.ReadLine();
        }
    }
}
