﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caseletexam
{
    class InternationalAirport : AirportEssentials
    {
        int minRequiredAirStripLength = 10000;
        int minNoOfFligthsADay = 100;
        int maxNoOfFligthsADay = 1300;
        int DistanceFromCity = 1800;
        int flightsperday;
        int minairbridge;
        Random r = new Random();
        static int AirportCode;

        public override void AddNewAirport()
        {
            int distance = GetInt("EnterDistance");
            if (distance >= DistanceFromCity)
            {
                Console.WriteLine("Enter airportname");
                airportname = Console.ReadLine();
                Console.WriteLine("airport id");
                Console.WriteLine(airportid);
                Console.WriteLine("Enter cityname");
                cityname = Console.ReadLine();
                try
                {
                    //Console.WriteLine("Enter allottedareaforairport");
                    allotedareaforairport = GetInt("Enter allottedareaforairport");
                    if (allotedareaforairport > minRequiredAirStripLength)
                    {
                        Console.WriteLine("Allotted area for airport is available");

                    }
                    else
                    {
                        throw new MinRequiredArea(" allocated area should be greater than minimum required area");
                    }
                }
                catch (MinRequiredArea e)
                {
                    Console.WriteLine(e.Message);
                }
                allotedareaforparking = GetInt(" enter Parking area for airport");
                Console.WriteLine("enter address");
                address = Console.ReadLine();
                AirportCode = AirportEssentials.genRandomnum();
                Console.WriteLine("AirportCode is{0}", AirportCode);
                //  Console.WriteLine("  enter the no. of flights a day");
                try
                {
                    flightsperday = GetInt(" enter the no. of flights a day");
                    /*    DateTime nextdate = DateTime.Today.AddDays(1.0);
                        DateTime currentdatetime = DateTime.Now;
                        int compareresult = DateTime.Compare(currentdatetime, nextdate);
                        if (compareresult == 0)
                        {*/
                    try
                    {

                        if (flightsperday < minNoOfFligthsADay)
                        {
                            
                            throw new MinFlightsperday("No.of flights moving per day is greater than  minNoOfFligthsADay ");
                        }
                        else if (flightsperday > maxNoOfFligthsADay)
                        {
                            throw new MaxFlightsperday("No.of flights moving per day is greater than  maxNoOfFligthsADay ");
                        }
                        else
                        {
                            Console.WriteLine(" No.of flights moving per day is{0} ", flightsperday);
                        }
                    }
                   
                    catch (MaxFlightsperday e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (MinFlightsperday e)
                    {
                        Console.WriteLine(e.Message);
                    }

                }
                finally
                {
                    Console.WriteLine("these are the details of newairport");
                }
            }
        }
        public override void RemoveAirport()
        {
            Console.WriteLine("enter the airportid");
            int id = Convert.ToInt32(Console.ReadLine());
            InternationalAirport result = Program.calist.Find(item => item.airportid == id);
            if (result != null)
            {
                Program.calist.Remove(result);
            }
            else
            {
                Console.WriteLine("Enter valid Airport id");

            }
        }
        public override void EditAirportDetails()
        {
            Console.WriteLine("enter the airportid");
            int id = Convert.ToInt32(Console.ReadLine());
            InternationalAirport result = Program.calist.Find(item => item.airportid == id);
            if (result != null)
            {
                Console.WriteLine("Enter the  airport name to be modified");
                result.airportname = Console.ReadLine();
                Console.WriteLine("Enter the  airport area to be modified");
                result.cityname = Console.ReadLine();
                Console.WriteLine("Enter the  airport  location to be modified");
                result.address = Console.ReadLine();
                Console.WriteLine("modified details are for{0}", AirportCode);
                Console.WriteLine(result.cityname);
                Console.WriteLine(result.address);
                Console.WriteLine(result.airportname);
            }
            else
            {
                Console.WriteLine("Enter valid Airport id");
            }
        }
        public override void ShowAirportDetails()
        {
            Console.WriteLine("enter the airportcode");
            int code = Convert.ToInt32(Console.ReadLine());
            InternationalAirport result = Program.calist.Find(item => AirportCode == code);
            if (result != null)
            {
                Console.WriteLine(" details for the given airport id");
                Console.WriteLine(result.airportname);
                Console.WriteLine(result.cityname);
                Console.WriteLine(result.address);
                Console.WriteLine(result.allotedareaforparking);
                Console.WriteLine(result.allotedareaforairport);
                Console.WriteLine(AirportCode);

            }
            else
            {
                Console.WriteLine("Enter valid Airport id");
            }
        }
        public override void GetDetailsForNewAirport()
        {
            Console.WriteLine("enter the airportcode");
            int code = Convert.ToInt32(Console.ReadLine());
            InternationalAirport result = Program.calist.Find(item => AirportCode == code);
            if (result != null)
            {
                Console.WriteLine("Enter the necessary details of the particular airport code");
                Console.WriteLine("1. name of the airport \n 2.airportid \n 3.cityname \n 4.allottedareafor airport \n 5.allottedareaforparking \n 6. address");
                int choice = GetInt("Enter the choice");
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("name of the airport is {0}", result.airportname);
                        break;
                    case 2:
                        Console.WriteLine(" airportid is {0}", result.airportid);
                        break;
                    case 3:
                        Console.WriteLine("name of the city is {0}", result.cityname);
                        break;
                    case 4:
                        Console.WriteLine("allotted area for airport is {0}", result.allotedareaforparking);
                        break;
                    case 5:
                        Console.WriteLine("allotted area for parking is {0}", result.allotedareaforairport);
                        break;
                    case 6:
                        Console.WriteLine(" address of the airport {0}", result.address);
                        break;
                    default:
                        Console.WriteLine("enter valid option");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Enter valid Airport id");
            }
        }
        public static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }
    }

}





















