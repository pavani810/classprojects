﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    enum e
    {
        deposit=1,
        withdraw=2
    };

    class Bankaccount
    {
        public static int Length { get; private set; }

        static void Main(string[] args)
        {

            Bank user1 = new Bank();
            user1.values();
            DisplayMenu();
            Console.WriteLine("Choose the choice of operation");
            int choice = int.Parse(Console.ReadLine());
            switch ((e)choice)
            {


                case e.deposit:
                    user1.depositamount();
                    break;
                case e.withdraw:
                    user1.withdrawamount();
                    break;
            }


        }

        static void DisplayMenu()
        {
            string[] menu =
            {
                "1.Deposit the amount",
                "2.Withdraw the amount"
              };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }

        }

        class Bank
        {

            public string name;
            public string acc_num;
            public string accType;
            public double bal;

            //Purpose:To set the initial values for the account

            public void values()
            {

                Console.WriteLine("Enter the name of account holder");
                name = Console.ReadLine();
                Console.WriteLine("Enter the account number");
                acc_num = Console.ReadLine();
                Console.WriteLine("Enter the account type");
                accType = Console.ReadLine();
                Console.WriteLine("Enter the amount");
                bal = int.Parse(Console.ReadLine());
                display();

            }


            // To deposit the amount in to the bank account
            public void depositamount()
            {

                Console.WriteLine("Please enter the account number to which the amount is to be deposited");
                string accnumber = Console.ReadLine();

                if (accnumber == acc_num)
                {
                    Console.WriteLine("Enter the amount to be deposited");
                    bal = bal + double.Parse(Console.ReadLine());
                }

                else
                {
                    Console.WriteLine("The account number is not invalid");

                }
                display();
                Console.ReadLine();
            }

            //To withdraw the amount from the bank account


            public void withdrawamount()
            {

                Console.WriteLine("Please enter the account number to which the amount is to be deposited");
                string accnumber = Console.ReadLine();

                if (accnumber == acc_num)
                {
                    Console.WriteLine("Enter the amount to be withdrawn");
                    bal = bal - Double.Parse(Console.ReadLine());
                }

                else
                {
                    Console.WriteLine("The account number is not invalid");

                }
                display();
                Console.ReadLine();
            }

            //To display the details of the account holder

            public void display()
            {
                Console.WriteLine("The bankacoount holder {0} maintaining the balane {1}", name, bal);
            }
        }
    }
}  