﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conversion
{

    class Program
    {
        static void Main(string[] args)
        {
            displaymenu();
            //get users choice
            int choice;
            choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Double dollar, rupee;
                    Console.WriteLine("Enter the Dollar Amount :");
                    dollar = Double.Parse(Console.ReadLine());
                    rupee = dollar * 65.48;
                    Console.WriteLine("{0} Dollar is Equal to {1} Rupees", dollar, rupee);
                    break;
                case 2:
                    Double dollar2, pounds;
                    Console.WriteLine("Enter the Dollar Amount :");
                    dollar2 = Double.Parse(Console.ReadLine());
                    pounds = dollar2 * 0.81;
                    Console.WriteLine("{0} Dollar is Equal to {1} pounds", dollar2, pounds);
                    break;
            }
            Console.ReadKey();
         }
          private static void displaymenu()
          {
               Console.WriteLine("Enter your Choice :\n 1- Dollar to Rupee \n 2- Dollar to Pound  ");
          }
                  
     }
 }
 

