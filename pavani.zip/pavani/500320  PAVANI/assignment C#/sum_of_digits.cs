﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sum_version2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = Convert.ToInt32(Console.ReadLine());
            double sum = num.ToString().Sum(s => Char.GetNumericValue(s));
            string sum1 = num.ToString();
            Console.WriteLine(sum);        
            Console.ReadLine();
        }
    }
}
