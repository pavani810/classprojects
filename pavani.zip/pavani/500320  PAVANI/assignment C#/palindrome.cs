﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindrome_version2
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            bool palindrome = IsPalindrome(s);
            if (palindrome)
            {
                Console.WriteLine("string is palindrome");
            }
            else
            {
                Console.WriteLine("string is not  palindrome");
            }
            Console.ReadLine();



        }
        public static bool IsPalindrome(string s)
        {
            return s == new string(s.Reverse().ToArray());
        }
    }
}
