﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pascal
{
    class pascaltriangle
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pascal Triangle");

            int n = 10;

            for (int p = 0; p < n; p++)

            {

                int c = 1;

                for (int q = 0; q < n - p; q++)

                {

                    System.Console.Write("   ");

                }



                for (int x = 0; x <= p; x++)

                {

                    System.Console.Write("   {0:D} ", c);

                    c = c * (p - x) / (x + 1);

                }

                System.Console.WriteLine();

                System.Console.WriteLine();

            }

            System.Console.WriteLine();
            Console.ReadLine();
        }
    }
}

