﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace value_of_money
{
    class value_of_money
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the principal amount");
            int pamt = int.Parse(Console.ReadLine());
            Console.WriteLine("enter period of years");
            int year = int.Parse(Console.ReadLine());
            Console.WriteLine("enter a rate");
            double rate = double.Parse(Console.ReadLine());
            Console.WriteLine("enter num");
            int num = int.Parse(Console.ReadLine());
            double temp = (1 + rate / num);
            double A = pamt * Math.Pow(temp, (num * year)); 
            double I = A - pamt;
            Console.WriteLine($"principal amount is{pamt}");
            Console.WriteLine($"interest is {I}");
            Console.WriteLine($"period in years is {year}");
            Console.WriteLine($"Final value is {A}");
            Console.ReadKey();
        }

    }  
}
