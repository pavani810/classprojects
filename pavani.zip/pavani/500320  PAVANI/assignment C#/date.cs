﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Date
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime date = new DateTime(1945, 8, 15);
            Console.WriteLine(date.ToString("dd'th' 'of' MMMM yyyy"));
            Console.WriteLine($"Date and Time:  {date}");
            DateTime presentDate = DateTime.Now;
            Console.WriteLine($"Date and Time:  {presentDate}");
            TimeSpan ts = presentDate - date;
            int differenceInDays = ts.Days;
            Console.WriteLine("Difference in days: {0} ", differenceInDays);
            Console.WriteLine(" difference in mintues : " + presentDate.Subtract(date).Minutes);
            Console.WriteLine(" difference in seconds : " + presentDate.Subtract(date).Seconds);
            Console.ReadKey();
        }
    }
}